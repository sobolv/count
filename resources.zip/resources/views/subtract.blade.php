<html>
<body>
    <h1>Результат віднімання:</h1>
    <h4>{{$num1}} - {{$num2}} = {{$res}} </h4>

    @extends('template')
</body>
</html>
